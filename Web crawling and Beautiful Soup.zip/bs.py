import urllib.request, urllib.parse, urllib.error
from bs4 import BeautifulSoup
import ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

url = input("URL: ")
htmlfile = urllib.request.urlopen(url, context = ctx).read()
soup = BeautifulSoup(htmlfile, "html.parser")
tags = soup("span")
sum = 0

for tag in tags:
    sum += int(tag.contents[0])

print("Sum: ",sum)
