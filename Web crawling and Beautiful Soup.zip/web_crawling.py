import urllib.request
from bs4 import BeautifulSoup
import ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

url = input("URL: ")
count = int(input("Enter Count: "))
pos = int(input("Enter Position: "))
htmlfile = urllib.request.urlopen(url, context = ctx).read()
soup = BeautifulSoup(htmlfile, "html.parser")
tags = soup("a")

for i in range(count):
    j = 0
    for tag in tags:
        if j == pos-1:
            url = tag.get("href", None)
            htmlfile = urllib.request.urlopen(url, context = ctx).read()
            soup = BeautifulSoup(htmlfile, "html.parser")
            tags = soup("a")
        if j == pos-1 and i == count-1:
            print("Last name in sequence: ", tag.contents[0])
        j += 1
